//Question 1
function User(n,a) {
    this.name = n;
    this.age = a;
  }
  let users = [];

  function makeObj() {
    const name = document.getElementById('name').value;
    const age = document.getElementById('age').value;

    const newUser = new User(name, age);
    users.push(newUser);
  }

  function displayObj() {
    const displayElement = document.getElementById('usersDisplay');
    displayElement.innerHTML = '';

    users.forEach(user => {
      displayElement.innerHTML += `Name: ${user.name}, Age: ${user.age}<br>`;

    });
  }

//Question 2

document.getElementById('btnq2').addEventListener('click', function() {
    fetch('./data/user.json')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(jsonData => {
        document.getElementById('jsonDataDisplay').textContent = JSON.stringify(jsonData, null, 2);
    })
    .catch(error => {
        console.error('Error fetching data: ', error);
        document.getElementById('jsonDataDisplay').textContent = 'Error loading data.';
    });
});


//Question 3
document.getElementById('btnq3').addEventListener('click', function() {
    fetch('https://jsonplaceholder.typicode.com/todos')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(todos => {
            displayTodos(todos);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
});

function displayTodos(todos) {
    const container = document.getElementById('todosContainer');
    
    container.innerHTML = '';

    const list = document.createElement('ul');
    todos.forEach(todo => {
        const listItem = document.createElement('li');
        listItem.classList.add('todo-item');
        if (todo.completed) {
            listItem.classList.add('completed');
        }
        listItem.textContent = todo.title;
        list.appendChild(listItem);
    });

    
    container.appendChild(list);
}
